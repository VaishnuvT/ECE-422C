package assignment2;

import java.util.ArrayList;

public class Board {
    private ArrayList<Code> guesses;
    private ArrayList<Result> results;  // This should be Result not r
    
    public Board() {
        guesses = new ArrayList<>();
        results = new ArrayList<>();
    }
    
    public void addGuess(Code guess, Result result) {
        guesses.add(guess);
        results.add(result);
    }
    
    public void printHistory() {
        if (guesses.size() == 0) {
            // print nothing when history is empty
            return;
        }

        for (int i = 0; i < guesses.size(); i++) {
            // use fixed spacing to match expected output (8 spaces)
            System.out.println(guesses.get(i).toString() + "        " + results.get(i).toString());
        }
    }
}